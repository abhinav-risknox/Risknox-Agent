package org.opensearch.dataprepper.plugins.windowsevent;

import org.opensearch.dataprepper.model.annotations.DataPrepperPlugin;
import org.opensearch.dataprepper.model.annotations.DataPrepperPluginConstructor;
import org.opensearch.dataprepper.model.event.Event;
import org.opensearch.dataprepper.model.record.Record;
import org.opensearch.dataprepper.model.processor.Processor;

import java.time.Instant;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Data Prepper processor that converts raw Windows Event XML (in the
 * {@code data} field) into structured {@code winlog.*} JSON fields.
 *
 * <h3>Output structure:</h3>
 * <pre>
 * {
 *   "@timestamp": "...",
 *   "winlog": {
 *     "event_id": 1,
 *     "provider_name": "Microsoft-Windows-Sysmon",
 *     "channel": "Microsoft-Windows-Sysmon/Operational",
 *     "computer_name": "WORKSTATION-01",
 *     "record_id": 12345,
 *     "version": 5,
 *     "level": 4,
 *     "task": 1,
 *     "opcode": 0,
 *     "keywords": "0x8000000000000000",
 *     "process": { "pid": 1234, "thread_id": 5678 },
 *     "user": { "identifier": "S-1-5-18" },
 *     "event_data": {
 *       "Image": "C:\\Windows\\cmd.exe",
 *       "CommandLine": "cmd /c whoami",
 *       ...
 *     }
 *   }
 * }
 * </pre>
 *
 * <p>Non-winevent events (FIM, SystemInfo, logtail) pass through unchanged.</p>
 */
@DataPrepperPlugin(name = "windows_event_normalizer", pluginType = Processor.class, pluginConfigurationType = WindowsEventNormalizerConfig.class)
public class WindowsEventNormalizer implements Processor<Record<Event>, Record<Event>> {

    private final WindowsEventNormalizerConfig config;

    @DataPrepperPluginConstructor
    public WindowsEventNormalizer(final WindowsEventNormalizerConfig config) {
        this.config = config;
    }

    @Override
    public Collection<Record<Event>> execute(Collection<Record<Event>> records) {
        return records.stream().map(record -> {
            Event event = record.getData();

            // Skip non-winevent events (FIM, SystemInfo, logtail pass through unchanged)
            String sourceType = event.get("source_type", String.class);
            if (sourceType != null && !"winevent".equals(sourceType)) {
                return record;
            }

            String xmlData = event.get(config.getSourceField(), String.class);

            if (xmlData != null && !xmlData.isEmpty() && xmlData.trim().startsWith("<")) {
                processXmlEvent(event, xmlData);
            }

            return record;
        }).collect(Collectors.toList());
    }

    /**
     * Parse the XML and write structured winlog.* fields into the event.
     */
    private void processXmlEvent(Event event, String xmlData) {
        XmlParserUtils.ParsedEvent parsed = XmlParserUtils.parse(xmlData);

        // ── @timestamp ─────────────────────────────────────────────────────
        String timestamp = parsed.systemFields.get("TimeCreated_SystemTime");
        if (timestamp == null || timestamp.isEmpty()) {
            // Fall back to the event's incoming timestamp
            timestamp = event.get("timestamp", String.class);
        }
        if (timestamp == null || timestamp.isEmpty()) {
            timestamp = Instant.now().toString();
        }
        event.put("@timestamp", timestamp);

        // ── winlog object ──────────────────────────────────────────────────
        Map<String, Object> winlog = new LinkedHashMap<>();

        // Core identifiers
        winlog.put("event_id", safeParseInt(parsed.systemFields.get("EventID")));
        putIfPresent(winlog, "provider_name", parsed.systemFields.get("Provider_Name"));
        putIfPresent(winlog, "provider_guid", parsed.systemFields.get("Provider_Guid"));
        putIfPresent(winlog, "channel", parsed.systemFields.get("Channel"));
        putIfPresent(winlog, "computer_name", parsed.systemFields.get("Computer"));

        // Numeric system fields
        Integer recordId = safeParseInt(parsed.systemFields.get("EventRecordID"));
        if (recordId != null) winlog.put("record_id", recordId);

        Integer version = safeParseInt(parsed.systemFields.get("Version"));
        if (version != null) winlog.put("version", version);

        Integer level = safeParseInt(parsed.systemFields.get("Level"));
        if (level != null) winlog.put("level", level);

        Integer task = safeParseInt(parsed.systemFields.get("Task"));
        if (task != null) winlog.put("task", task);

        Integer opcode = safeParseInt(parsed.systemFields.get("Opcode"));
        if (opcode != null) winlog.put("opcode", opcode);

        putIfPresent(winlog, "keywords", parsed.systemFields.get("Keywords"));

        // Process info from Execution attributes
        String procId = parsed.systemFields.get("Execution_ProcessID");
        String threadId = parsed.systemFields.get("Execution_ThreadID");
        if (procId != null || threadId != null) {
            Map<String, Object> process = new LinkedHashMap<>();
            if (procId != null) process.put("pid", safeParseInt(procId));
            if (threadId != null) process.put("thread_id", safeParseInt(threadId));
            winlog.put("process", process);
        }

        // Security user identifier
        String userId = parsed.systemFields.get("Security_UserID");
        if (userId != null && !userId.isEmpty()) {
            Map<String, Object> user = new LinkedHashMap<>();
            user.put("identifier", userId);
            winlog.put("user", user);
        }

        // Correlation
        putIfPresent(winlog, "activity_id", parsed.systemFields.get("Correlation_ActivityID"));

        // ── event_data: ALL EventData fields with original PascalCase names ──
        // All values stored as strings (keyword-mapped in OpenSearch)
        winlog.put("event_data", parsed.eventData);

        // Write the winlog object into the event
        event.put("winlog", winlog);

        // ── Drop raw XML if configured ─────────────────────────────────────
        if (config.isDropRawXml()) {
            event.delete(config.getSourceField());
        }
    }

    private static void putIfPresent(Map<String, Object> map, String key, String value) {
        if (value != null && !value.isEmpty()) {
            map.put(key, value);
        }
    }

    private static Integer safeParseInt(String value) {
        if (value == null || value.isEmpty()) return null;
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public void prepareForShutdown() {}

    @Override
    public boolean isReadyForShutdown() { return true; }

    @Override
    public void shutdown() {}
}
